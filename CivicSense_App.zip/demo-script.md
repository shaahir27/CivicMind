# CivicMind Demo Script

This script provides a step-by-step narrative for demonstrating the CivicSense platform from both the citizen and authority perspectives.

## Setup & Preparation
1. Ensure the backend server is running (`npm run dev:backend`) or deployed.
2. Ensure the citizen and authority frontends are running locally or deployed.
3. Keep the Firebase console open to show real-time database updates.

## Part 1: The Citizen Experience (Issue Reporting)

**Goal:** Demonstrate how easy it is for a citizen to report an issue, and how the AI Reporter and Validator agents instantly process it.

1. **Open the Citizen App** and log in as `demo-citizen`.
2. **Navigate to the Home screen** to see the feed of local issues. Point out that the system already has historical data seeded, giving it a realistic feel.
3. **Tap the "Report Issue" FAB (Floating Action Button).**
4. **Capture an Issue:**
   - Upload a photo of a pothole or street damage (or select a sample image).
   - Enter a brief description: *"Deep pothole on the main road, very dangerous for two-wheelers."*
   - Submit the report.
5. **The AI Reporter Agent:**
   - Explain that behind the scenes, the **Reporter Agent** is using the Gemini vision model to analyze the photo and description.
   - It automatically categorizes the issue (e.g., `road_damage`) and assesses the severity (e.g., `high`).
   - *Result:* The app immediately shows the suggested category and severity. The user confirms these details.
6. **The AI Validator & Router Agents:**
   - Explain that the **Validator Agent** checks for duplicates. If a similar pothole was already reported nearby, it would automatically merge them to prevent spam. Since this is new, it proceeds.
   - The **Router Agent** instantly assigns the issue to the correct department (e.g., BBMP) and specific ward jurisdiction. It calculates an SLA deadline based on the severity.
7. **View the Report:** The citizen is taken back to their feed, where they see their new issue marked as "Submitted" and assigned to the correct authority.

## Part 2: The Authority Experience (Issue Resolution)

**Goal:** Show how the platform empowers authority workers to manage issues, and how the Verifier agent enforces accountability.

1. **Open the Authority App** and log in as `demo-authority` (assigned to BBMP, Indiranagar).
2. **View the Dashboard:**
   - The dashboard shows issues assigned specifically to this authority's jurisdiction.
   - Point out the newly reported pothole issue. It appears with the "High" severity tag and a clearly visible SLA countdown.
3. **Acknowledge the Issue:**
   - Click on the issue to view details.
   - Click **"Acknowledge"**. The status changes from "Routed" to "In Progress". The citizen will be notified.
4. **Resolve the Issue (The Verifier Agent):**
   - Click **"Mark as Resolved"**.
   - The system *requires* an after-photo as proof of work. Upload a photo of the repaired road.
   - Submit the resolution.
5. **The AI Verifier Agent:**
   - Explain that the **Verifier Agent** now compares the *before* photo with the *after* photo using Gemini vision.
   - It verifies that the repair matches the original issue.
   - *Result:* The issue status is updated to `verified_resolved`. The authority worker earns "Hero Points" for a successful, verified resolution.

## Part 3: Escalation & SLAs (The Edge Cases)

**Goal:** Demonstrate the system's automated accountability mechanisms.

1. **Show a Breached SLA:**
   - Navigate to the "Escalations" view (if applicable) or look at an older seeded issue where the SLA deadline has passed.
   - Explain the **Escalation Agent**. It runs continuously in the background. When an issue breaches its SLA, the agent automatically escalates it to the next tier of management and notifies the relevant officials.
2. **Show a Disputed Resolution (Optional):**
   - Explain what happens if an authority uploads a fake "after" photo (e.g., a picture of a random street or a black image).
   - The Verifier Agent will detect the mismatch, reject the resolution, flag the issue as `disputed_resolution`, and reopen the SLA timer.

## Summary

Conclude the demo by summarizing the value proposition:
- **For Citizens:** A frictionless, responsive way to improve their city.
- **For Authorities:** An automated triage system that reduces noise and prioritizes critical issues.
- **For the City:** Built-in accountability through AI verification and automated SLAs, ensuring real work gets done.
